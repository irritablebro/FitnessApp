package com.example.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Diet_ditail extends AppCompatActivity {
    ImageView iv;
    TextView tv_dis;
     Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet_ditail);
        tv_dis=findViewById(R.id.tv_d_dis);
         iv=findViewById(R.id.iv_d_chanpin);
         btn=findViewById(R.id.btn_d_back);
         Intent intent=getIntent();
         tv_dis.setText(intent.getStringExtra("name"));
         iv.setImageResource(intent.getIntExtra("img",R.mipmap.cereals));
         btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                              finish();
                          }
       });
    }
}