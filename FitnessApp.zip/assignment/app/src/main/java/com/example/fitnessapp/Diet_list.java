package com.example.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class Diet_list extends AppCompatActivity {
    TextView tv;
    ListView lv;
    SimpleAdapter sa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet_list);
        tv = findViewById(R.id.tv_dis);
        lv = findViewById(R.id.lv_kfc);
        sa = new SimpleAdapter(this,getData(), R.layout.diet_item,new String[]{"img","name"},new int[]{R.id.list_iv,R.id.list_tv_name});
        lv.setAdapter(sa);
        lv.setOnItemClickListener((adapterView, view, i, l)-> {
            Map<String,Object> clickmap=(Map<String, Object>) adapterView.getItemAtPosition(i);//注意:adapterView.getItem(没有ID)AtPosition(i)
            String name=clickmap.get("name").toString();
            int img=(int)clickmap.get("img");
            tv.setText(name);
            Intent intent=new Intent(Diet_list.this,Diet_ditail.class);
            intent.putExtra("name",name);
            intent.putExtra("img",img);
            startActivity(intent);
        });
    }

    private List<Map<String,Object>> getData() {
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("img",R.mipmap.cereals);
        map.put("name","Cereals");
        list.add(map);

        map=new HashMap<String,Object>();
        map.put("img",R.mipmap.berries);
        map.put("name","Berries");
        list.add(map);
        map=new HashMap<String,Object>();
        map.put("img",R.mipmap.fish);
        map.put("name","Fish");
        list.add(map);
        map=new HashMap<String,Object>();
        map.put("img",R.mipmap.almonds);
        map.put("name","Almond");
        list.add(map);
        map=new HashMap<String,Object>();
        map.put("img",R.mipmap.salad);
        map.put("name","Salad");
        list.add(map);
        map=new HashMap<String,Object>();
        map.put("img",R.mipmap.broccoli);
        map.put("name","Broccoli");
        list.add(map);
        map=new HashMap<String,Object>();
        map.put("img",R.mipmap.vegetable_skewer);
        map.put("name","Vegetable skewer");
        list.add(map);

        return list;
    }
}