package com.example.fitnessapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public int Sign_RequestCode=1;
    Button sign;
    Button login;
    EditText username;
    EditText psw;
    CheckBox remember;

    DBOpenHelper DB;
    private SharedPreferences preferences;
    private SharedPreferences .Editor editor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sign=findViewById(R.id.login_btn_sign);
        login=findViewById(R.id.login_btn_login);
        username=findViewById(R.id.login_username);
        psw=findViewById(R.id.login_psw);
        remember=findViewById(R.id.login_remember);

        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor=preferences.edit();
        boolean isRemember=preferences.getBoolean("remember_password",false);
        if(isRemember){
            String rem_username=preferences.getString("login_username","");
            String rem_password=preferences.getString("login_psw","");
            username.setText(rem_username);
            psw.setText(rem_password);
            remember.setChecked(true);
        }

        DB=new DBOpenHelper(this);


        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent();
                intent.setClass(MainActivity.this,Sign.class);
                startActivity(intent);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user=username.getText().toString();
                String pass=psw.getText().toString();

                if(TextUtils.isEmpty(user)||TextUtils.isEmpty(pass)){
                    Toast.makeText(MainActivity.this,"All fields required ",Toast.LENGTH_SHORT).show();
                }else{
                    Boolean checkuserpass=DB.checkpassword(user,pass);
                    if(checkuserpass==true){
                        Toast.makeText(MainActivity.this,"Login successful",Toast.LENGTH_SHORT).show();

                        if(remember.isChecked()){
                            editor.putBoolean("remember_password",true);
                            editor.putString("login_username", user);
                            editor.putString("login_psw", pass);
                        }else{
                            editor.remove("rem_username").remove("rem_password");
                        }
                        editor.apply();

                        Intent intent=new Intent(getApplicationContext(),Welcome.class);
                        //intent.putExtra("username",user);


                        startActivity(intent);
                    }else{
                        Toast.makeText(MainActivity.this,"Login failed",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


    }



}