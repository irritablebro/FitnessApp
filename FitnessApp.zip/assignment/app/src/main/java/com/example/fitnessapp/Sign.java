package com.example.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.BoringLayout;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Sign extends AppCompatActivity {

    Button back;
    Button register;
    EditText username;
    EditText psw;
    EditText repsw;


    DBOpenHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign);

        back=findViewById(R.id.sign_back);
        register=findViewById(R.id.sign_btn_register);
        username=findViewById(R.id.sign_username);
        psw=findViewById(R.id.sign_psw);
        repsw=findViewById(R.id.sign_repsw);

        DB=new DBOpenHelper(this);


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user=username.getText().toString();
                String pass=psw.getText().toString();
                String repass=repsw.getText().toString();
                String name=repsw.getText().toString();


                if(TextUtils.isEmpty(user)||TextUtils.isEmpty(pass)||TextUtils.isEmpty(repass)){
                    Toast.makeText(Sign.this,"All fields required",Toast.LENGTH_SHORT).show();
                }else {
                    if(pass.equals(repass)){
                        Boolean checkuser=DB.checkusername(user);
                        if(checkuser==false){
                            Boolean insert=DB.insertData(user,pass);
                            if(insert==true){
                                Intent intent=new Intent(getApplicationContext(),Welcome.class);

                                Toast.makeText(Sign.this,"Registration Successfully",Toast.LENGTH_SHORT).show();
                              startActivity(intent);
                            }else{
                                Toast.makeText(Sign.this,"Registration failed",Toast.LENGTH_SHORT).show();
                            }

                        }else{
                            Toast.makeText(Sign.this,"User already exist",Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(Sign.this,"Password are not matching",Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);

            }
        });
    }
}