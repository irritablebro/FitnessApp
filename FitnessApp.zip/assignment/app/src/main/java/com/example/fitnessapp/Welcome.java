package com.example.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatSeekBar;
import androidx.appcompat.widget.SwitchCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class Welcome extends AppCompatActivity {
    TextView age;
    TextView weight;
    TextView height;
    EditText name;
    //TextView label;
    AppCompatSeekBar seekBar;
    RadioGroup gender;
    RadioButton male;
    RadioButton female;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        age=findViewById(R.id.age);
        weight=findViewById(R.id.weight);
        height=findViewById(R.id.height);
        name=findViewById(R.id.wel_edit_Name);
        //label=findViewById(R.id.bmi_label);
        seekBar=findViewById(R.id.seek_bar);
        seekBar.setOnSeekBarChangeListener(listener);
        gender=findViewById(R.id.wel_gender);
        male=findViewById(R.id.wel_male);
        female=findViewById(R.id.wel_female);

//        gender.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){
//                if(male.isChecked()){
//                    Toast.makeText(Welcome.this,"性别是:男",Toast.LENGTH_SHORT).show();
//                }
//                if (female.isChecked()){
//                    Toast.makeText(Welcome.this,"性别是:女",Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
    }


    private SeekBar.OnSeekBarChangeListener listener=new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {

            height.setText(String.valueOf(progress));
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    };

    public void increaseAge(View view) {
        if(Integer.parseInt(age.getText().toString())>0){
            int age_value=Integer.parseInt(age.getText().toString())+1;
            age.setText(String.valueOf(age_value));
        }
    }

    public void decreaseAge(View view) {
        if(Integer.parseInt(age.getText().toString())>0){
            int age_value=Integer.parseInt(age.getText().toString())-1;
            age.setText(String.valueOf(age_value));
        }
    }

    public void increaseWeight(View view) {
        if(Integer.parseInt(weight.getText().toString())>0){
            int weight_value=Integer.parseInt(weight.getText().toString())+1;
            weight.setText(String.valueOf(weight_value));
        }
    }

    public void decreaseWeight(View view) {
        if(Integer.parseInt(weight.getText().toString())>0){
            int weight_value=Integer.parseInt(weight.getText().toString())-1;
            weight.setText(String.valueOf(weight_value));
        }
    }


    public void calculate(View view) {
        Double get_height = Double.parseDouble(height.getText().toString())/100;
        Double get_weight = Double.parseDouble(weight.getText().toString());
        Integer get_age=Integer.parseInt(age.getText().toString());
        //Toast.makeText(Welcome.this,"Your age is  "+get_age,Toast.LENGTH_SHORT).show();
        Double bmi=get_weight/(get_height*get_height);
        String bmi_value= String.format("%.1f",bmi);

        Toast.makeText(Welcome.this,"Your bmi is  "+bmi_value,Toast.LENGTH_SHORT).show();

        String username=name.getText().toString();



        Intent intent=new Intent(getApplicationContext(), Personal.class);


        String maleuser="Male";
        String femaleuser="Female";
        if(male.isChecked()){
            intent.putExtra("usergender",maleuser);
        }else{
            intent.putExtra("usergender",femaleuser);

        }
        intent.putExtra("userage",get_age);

        intent.putExtra("username",username);
        intent.putExtra("bmi_value",bmi_value);
        startActivity(intent);
    }


}