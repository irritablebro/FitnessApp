package com.example.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;

public class Personal extends AppCompatActivity {

    TextView name;
    TextView age;
    TextView gender;
    TextView bmi;
    //ImageView img;
    TextView bmi_des;
    LottieAnimationView head;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal);
        age=findViewById(R.id.per_age);
        bmi=findViewById(R.id.per_bmi);
        name=findViewById(R.id.per_name);
        gender=findViewById(R.id.per_gender);
        //img=findViewById(R.id.per_image);
        head=findViewById(R.id.per_head);
        bmi_des=findViewById(R.id.per_bmi_description);



        Intent intent=getIntent();
        String bmi_value=intent.getStringExtra("bmi_value");
        String usergender=intent.getStringExtra("usergender");
        String username=intent.getStringExtra("username");
        String userage=String.valueOf(intent.getIntExtra("userage",20));
        age.setText("Age: "+userage);
        gender.setText("Gender: " +usergender);
        if(username.isEmpty()){
            name.setText("User");
        }else{
            name.setText("Name:"+username);
        }
        bmi.setText("Your BMI is : "+bmi_value);

        if(Double.parseDouble(bmi_value)<18.5){
            bmi_des.setText("You're in the underweight range" +
                    " If your BMI is below 18.5, this suggests that your weight may be too low." +
                    " If you feel anxious or worried when you think about food, or feel that stress " +
                    " are affecting the way you eat, you may have an eating disorder.");
        }else if(Double.parseDouble(bmi_value)>=18.5&&Double.parseDouble(bmi_value)<25){
            bmi_des.setText("You're in the healthy weight range" +
                    " Please keeping your diet habbit" +
                    " Eating healthy food is helpful for keep body");
        }else if(Double.parseDouble(bmi_value)>=25&&Double.parseDouble(bmi_value)<30){
            bmi_des.setText("You're in the overweight range " +
                    "The higher your BMI, the higher your risk for certain diseases such as heart disease, " +
                    "high blood pressure, type 2 diabetes, gallstones, breathing problems, and certain cancers." +
                    "We are recommend you to eat more helthy food");
        }else if(Double.parseDouble(bmi_value)>=30){
            bmi_des.setText("You're in the obese range" +
                    " You need to lose weight now"+
                    " Please exercise now and have a better diet");
        }
    }

    public void per_diet(View view) {
        Intent intent=new Intent(getApplicationContext(), Diet_list.class);
        startActivity(intent);
    }

    public void per_sport(View view) {
        Intent intent=new Intent(getApplicationContext(), Sport_list.class);
        startActivity(intent);
    }
}